//
//  AppDelegate.swift
//  SCIFriends
//
//  Created by Aemon Rose on 7/7/25.
//

import Cocoa

@main
class AppDelegate: NSObject, NSApplicationDelegate {
    
    // MARK: - Properties
    /// 窗口控制器，用于引用主窗口
    private var mainWindowController: NSWindowController?
    
    // MARK: - Application Lifecycle
    func applicationDidFinishLaunching(_ aNotification: Notification) {
        // 初始化全局宠物管理器
        _ = PetManager.shared
        
        // 从 Main.storyboard 实例化并展示主窗口
        let storyboard = NSStoryboard(name: "Main", bundle: nil)
        guard let windowController = storyboard.instantiateController(withIdentifier: "MainWindowController") as? NSWindowController else {
            assertionFailure("无法在 Main.storyboard 中找到 MainWindowController")
            return
        }
        self.mainWindowController = windowController
        windowController.showWindow(self)
        
        // 监听宠物状态更新通知，更新 Dock 角标
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(handlePetUpdate(_:)),
                                               name: .petDidUpdate,
                                               object: nil)
    }

    func applicationWillTerminate(_ aNotification: Notification) {
        // 移除所有通知观察者
        NotificationCenter.default.removeObserver(self)
    }

    // MARK: - State Restoration
    func applicationSupportsSecureRestorableState(_ app: NSApplication) -> Bool {
        return true
    }

    // MARK: - Window Behavior
    /// 当最后一个窗口关闭后是否终止应用
    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool {
        // macOS 桌面应用常保持运行，可根据需求改为 true
        return false
    }

    // MARK: - Pet Update Handling
    @objc private func handlePetUpdate(_ notification: Notification) {
        let state = PetManager.shared.currentPet.currentState
        // 利用 Dock Tile 角标展示当前状态
        NSApp.dockTile.badgeLabel = state == .idle ? nil : state.rawValue.capitalized
        NSApp.dockTile.display()
    }
}
